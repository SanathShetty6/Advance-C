/*
NAME: SANATH SHETTY P
DATE: 26/03/2024
DESCRIPTION: WAP to implement getword function
SAMPLE INPUT: 
Test Case 1:
user@emertxe] ./getword
Enter the string : Welcome to Emertxe
You entered Welcome and the length is 7

Test Case 2:
user@emertxe] ./getword
Enter the string : Hello
You entered Hello and the length is 5
SAMPLE OUTPUT:
Test Case 1: You entered Welcome and the length is 7
Test Case 2: You entered Hello and the length is 5
*/

#include <stdio.h>

// Function prototype
int getword(char str[]);

// Main function
int main()
{
    // Declare variables
    int len = 0;
    char str[100];

    // Prompt the user to enter a string
    printf("Enter the string : ");
    
    // Read the string entered by the user
    scanf(" %s", str);

    // Call the function to get the length of the word
    len = getword(str);

    // Print the entered string and its length
    printf("You entered %s and the length is %d\n", str, len);
}

// Function to get the length of a word
int getword(char *str)
{
    // Declare variables
    int length = 0;

    // Loop until the end of the string
    while (*str != '\0')
    {
        // Move to the next character and increment the length
        *str++;
        length++;
    }

    // Return the length of the word
    return length;
}

