/*
NAME: SANATH SHETTY P
DATE: 28/02/2024
DESCRIPTION:WAP to check N th bit is set or not, If yes, clear the M th bit
SAMPLE INPUT:
Test Case 1:
Enter the number: 19
Enter 'N': 1
Enter 'M': 4
Test Case 2:
Enter the number: 19
Enter 'N': 2
Enter 'M': 4
SAMPLE OUTPUT:
Test Case 1:
Updated value of num is 3
Test Case 2:
Updated value of num is 19
*/

#include <stdio.h>

int main()
{
    int num, N, M, mask;

    // Read the integers num,N
    printf("Enter the number : ");
    scanf("%d", &num);
    printf("Enter 'N' : ");
    scanf("%d", &N);
    //Check the bit is set or not
    if (num & (1 << N))
    {
        //if yes enter M bit
        printf("Enter 'M' : ");
        scanf("%d", &M);
        //Clear M bit and store in num
        num = num & ~(1 << M);
    }

    //Print output
    printf("Updated value of num is %d\n", num);
    return 0;

}

