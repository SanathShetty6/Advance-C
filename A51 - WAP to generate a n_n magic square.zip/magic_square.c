/*
NAME: SANATH SHETTY P
DATE: 15/04/2024
DESCRIPTION: WAP to generate a n*n magic square
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./magic_square
Enter a number: 3

Test Case 2:
Enter a number: 6

SAMPLE OUTPUT:
Test Case 1: 
8      1      6
3      5      7
4      9      2

Test Case 2: Error : Please enter only positive values
*/

#include <stdio.h>
#include <stdlib.h>

// Function prototype
void magic_square(int **, int);

int main() {
    int n;
    //printf("Enter a number: ");
    scanf("%d", &n);

    // Check if n is even or negative
    if (n % 2 == 0 || n <= 0) {
        printf("Error: Please enter only positive odd numbers");
        return 1; // Exit with error code 1
    }

    // Allocate memory for the magic square matrix
    int **magicsquare = (int **)malloc(n * sizeof(int *));
    if (magicsquare == NULL) {
        return 1; // Exit with error code 1
    }
    for (int i = 0; i < n; i++) {
        magicsquare[i] = (int *)malloc(n * sizeof(int));
        if (magicsquare[i] == NULL) {
            // Free previously allocated memory
            for (int j = 0; j < i; j++) {
                free(magicsquare[j]);
            }
            free(magicsquare);
            return 1; // Exit with error code 1
        }
    }

    // Generate the magic square
    magic_square(magicsquare, n);

    // Printing the magic square
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%-6d", magicsquare[i][j]);
        }
        printf("\n");
    }

    // Free dynamically allocated memory
    for (int i = 0; i < n; i++) {
        free(magicsquare[i]);
    }
    free(magicsquare);

    return 0;
}

// Function to generate the magic square
void magic_square(int **matrix, int n) {
    // Initialize all elements to zero
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrix[i][j] = 0;
        }
    }

    // Starting position
    int row = 0;
    int col = n / 2;
    int num = 1;

    // Fill the matrix with numbers
    while (num <= n * n) {
        matrix[row][col] = num;

        // Calculate the next position
        int nextRow = (row - 1 + n) % n;
        int nextCol = (col + 1) % n;

        // If the next position is already filled, move down
        if (matrix[nextRow][nextCol] != 0) {
            row = (row + 1) % n;
        } else {
            row = nextRow;
            col = nextCol;
        }

        num++;
    }
}
