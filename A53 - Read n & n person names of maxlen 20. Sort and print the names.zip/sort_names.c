/*
NAME: SANATH SHETTY P
DATE: 03/05/2024
DESCRIPTION: Read n & n person names of maxlen 20. Sort and print the names
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./sort

Enter the size: 5

Enter the 5 names of length max 20 characters in each
[0] -> Delhi
[1] -> Agra
[2] -> Kolkata
[3] -> Bengaluru
[4] -> Chennai

SAMPLE OUTPUT:
The sorted names are:
Agra
Bengaluru
Chennai
Delhi
Kolkata
*/

/*
NAME: SANATH SHETTY P
DATE: 03/05/2024
DESCRIPTION: Read n & n person names of maxlen 20. Sort and print the names
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./sort

Enter the size: 5

Enter the 5 names of length max 20 characters in each:
[0] -> Delhi
[1] -> Agra
[2] -> Kolkata
[3] -> Bengaluru
[4] -> Chennai

SAMPLE OUTPUT:
The sorted names are:
Agra
Bengaluru
Chennai
Delhi
Kolkata
*/

#include <stdio.h>
#include <stdlib.h>

// Function prototypes
void sort_names(char (*ptr)[20], int size);
int my_strcmp(char *str1, char *str2);

int main()
{
    int size;
    // Prompting the user to enter the number of names
    printf("Enter the size: ");
    scanf("%d", &size);

    // Dynamically allocate memory for storing names
    char(*names)[20] = malloc(size * sizeof(char[20]));

    // Check if memory allocation is successful
    if (names == NULL)
    {
        printf("Memory allocation failed\n");
        return 1;
    }

    // Prompting the user to enter names
    printf("Enter the %d names of length max 20 characters in each:\n", size);
    for (int i = 0; i < size; i++)
    {
        printf("[%d] -> ", i);
        scanf("%19s", names[i]);
    }

    // Sorting the names
    sort_names(names, size);

    // Printing the sorted names
    printf("\nThe sorted names are:\n");
    for (int i = 0; i < size; i++)
    {
        printf("%s\n", names[i]);
    }

    // Free dynamically allocated memory
    free(names);

    return 0;
}

// Function to sort an array of strings
void sort_names(char (*ptr)[20], int size)
{
    // Bubble sort algorithm for sorting strings
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (my_strcmp(ptr[j], ptr[j + 1]) > 0)
            {
                // Swap the strings directly
                char temp[20];
                for (int k = 0; k < 20; k++)
                {
                    temp[k] = ptr[j][k];
                    ptr[j][k] = ptr[j + 1][k];
                    ptr[j + 1][k] = temp[k];
                }
            }
        }
    }
}

// Function to compare two strings
int my_strcmp(char *str1, char *str2)
{
    // Compare each character of the strings
    while (*str1 && *str2 && *str1 == *str2)
    {
        str1++;
        str2++;
    }
    // Return the difference between the first non-matching characters
    return *str1 - *str2;
}
