/*
NAME: SANATH SHETTY P
DATE: 02/03/2024
DESCRIPTION: WAP to find the median of two unsorted arrays
SAMPLE INPUT:
est Case 1:

Enter the 'n' value for Array A: 5
Enter the 'n' value for Array B: 5
Enter the elements one by one for Array A: 3 2 8 5 4
Enter the elements one by one for Array B: 12 3 7 8 5

Test Case 2:
Enter the 'n' value for Array A: 5
Enter the 'n' value for Array B: 4
Enter the elements one by one for Array A: 3 2 8 5 4
Enter the elements one by one for Array B: 12 13 7 5

SAMPLE OUTPUT:
Test Case 1:
Median of array1 : 4
Median of array2 : 7
Median of both arrays : 5.5

Test Case 2:
Median of array1 : 4
Median of array2 : 9.5
Median of both arrays : 6.75
*/

#include <stdio.h>

int main()
{
    int A, B, i, j,m,n, arr1[50], arr2[70], temp;
    int M1,Med1,M2,Med2;
    float avg1, avg2;

    //Enter the input for both arrays
    printf("Enter the 'n' value for Array A: ");
    scanf("%d", &A);
    printf("Enter the 'n' value for Array B: ");
    scanf("%d", &B);
    printf("Enter the elements one by one for Array A:");
    for (i = 0; i < A; i++)
    {
        scanf("%d", &arr1[i]);
    }
    printf("Enter the elements one by one for Array B:");
    for (i = 0; i < B; i++)
    {
        scanf("%d", &arr2[i]);
    }

    // Bubble sort of array 1 and array 2
    //For array1
    for (i = 0; i < A - 1; i++)
    {
        for (j = 0; j < A - i - 1; j++)
        {
            if (arr1[j] > arr1[j + 1])
            {
                temp = arr1[j];
                arr1[j] = arr1[j + 1];
                arr1[j + 1] = temp;
            }
        }
    }
    //for array2
    for (m = 0; m < B - 1; m++)
    {
        for (n = 0; n < B - m - 1; n++)
        {
            if (arr2[n] > arr2[n + 1])
            {
                temp = arr2[n];
                arr2[n] = arr2[n + 1];
                arr2[n + 1] = temp;
            }
        }
    }

    //Average of 2 arrays
    if (A % 2 == 0) // median of even elements

    {
        M1 = arr1[A / 2];
        Med1 = arr1[(A / 2) - 1];
        avg1 = ((float)M1 + Med1) / 2;
    }
    else // median of odd eelements
    {
        avg1 = arr1[A / 2];
    }
    if (B % 2 == 0) // for array2

    {
        M2 = arr2[B / 2];
        Med2 = arr2[(B / 2) - 1];
        avg2 = ((float)M2 + Med2) / 2;
    }
    else
    {
        avg2 = arr2[B / 2];
    }

    printf("Median of array1 : %g\n", avg1);
    printf("Median of array2 : %g\n", avg2);
    printf("Median of both arrays : %g\n", (avg1 + avg2) / 2);

    return 0;
}
