/*
NAME: SANATH SHETTY P
DATE: 18/04/2024
DESCRIPTION: WAP to implement fragments using Array of Pointers
SAMPLE INPUT: 
Test case 1:
user@emertxe] ./fragmentsEnter
Enter no.of rows : 3
Enter no of columns in row[0] : 4
Enter no of columns in row[1] : 3
Enter no of columns in row[2] : 5
Enter 4 values for row[0] : 1 2 3 4
Enter 3 values for row[1] : 2 5 9
Enter 5 values for row[2] : 1 3 2 4 1
SAMPLE OUTPUT:
Test case 1:
Before sorting output is:

1.000000 2.000000 3.000000 4.000000 2.500000

2.000000 5.000000 9.000000 5.333333

1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

After sorting output is:

1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

1.000000 2.000000 3.000000 4.000000 2.500000

2.000000 5.000000 9.000000 5.333333
*/

#include <stdio.h>
#include <stdlib.h>

int fragments(int rows, int *array) {
    int i, j;
    float *arr[rows]; // Array of pointers to store rows

    // Dynamically allocate memory for each row
    for (i = 0; i < rows; i++) {
        arr[i] = malloc(sizeof(float) * (array[i] + 1)); // Allocate memory for row values and an extra block for average
        printf("Enter %d values for row[%d]: ", array[i], i);
        for (j = 0; j < array[i]; j++) {
            if (scanf("%f", &arr[i][j]) != 1) // Read values for the row
                return 1;
        }
    }

    // Calculate average for each row and print rows before sorting
    printf("Before Sorting output is:\n");
    for (i = 0; i < rows; i++) {
        float sum = 0;
        for (j = 0; j < array[i]; j++) {
            printf("%f ", arr[i][j]); // Print values of the row
            sum += arr[i][j]; // Calculate sum for average
        }
        printf("%f\n", arr[i][j] = sum / j); // Calculate and store average in the extra block
    }

    // Sort rows based on their averages
    printf("After Sorting output is:\n");
    for (i = 0; i < rows - 1; i++) {
        for (j = 0; j < rows - i - 1; j++) {
            if (arr[j][array[j]] > arr[j + 1][array[j + 1]]) { // Compare averages
                float *temp = arr[j];
                arr[j] = arr[j + 1]; // Swap rows
                arr[j + 1] = temp;
                int temp1 = array[j];
                array[j] = array[j + 1]; // Swap row sizes
                array[j + 1] = temp1;
            }
        }
    }

    // Print sorted rows
    for (i = 0; i < rows; i++) {
        for (j = 0; j < array[i] + 1; j++) {
            printf("%f ", arr[i][j]); // Print values including average
        }
        printf("\n");
    }

    // Free dynamically allocated memory
    for (i = 0; i < rows; i++) {
        free(arr[i]);
    }
    return 0;
}

int main() {
    int rows;
    printf("Enter no of rows: ");
    if (scanf("%d", &rows) != 1)
        return 1;
    int array[rows];
    for (int i = 0; i < rows; i++) {
        printf("Enter no of columns in row[%d]: ", i);
        if (scanf("%d", &array[i]) != 1)
            return 1;
    }
    fragments(rows, array); // Call the fragments function
    return 0;
}


