/*
NAME: SANATH SHETTY P
DATE: 15/03/2024
DESCRIPTION: WAP to find 2nd largest element in an array
SAMPLE INPUT:
Test Case 1:
Enter the size of the Array : 5
Enter the elements into the array: 5 1 4 2 8

Test Case 2:
Enter the size of the Array : 4
Enter the elements into the array: 66 22 11 3

SAMPLE OUTPUT:
Test Case 1: Second largest element of the array is 5
Test Case 2: Second largest element of the array is 22
*/

#include <stdio.h>

int second_largest(int[], int);

int main()
{
    int size, ret, i;

    // Read size from the user
    //printf("Enter the size of the array :");
    scanf("%d", &size);

    int arr[size];

    // Read elements into the array
    //printf("Enter the elements into the array: ");
    for (i = 0; i < size; i++)
    {
        scanf("%d", &arr[i]);
    }

    // funtion call
    ret = second_largest(arr, size);

    // Print the output
    printf("Second largest element of the array is %d\n", ret);
}

// Function defination
int second_largest(int arr[], int size)
{
    // Declare the variables
    int i;
    int max1, max2;

    // Assign array of 0 value to max1

    max1 = arr[0];

    // To find second largest element
    for (i = 0; i < size; ++i)
    {
        if (max1 < arr[i]) // If first element smaller than array of i
        {
            max2 = max1;   // Assign max1 value to max2
            max1 = arr[i]; // And assign value array of i to max1
        }
        else if (arr[i] > max2 && arr[i] < max1) // Else if array of i greater than max2 and less than max1
        {
            max2 = arr[i]; // Assign array of i value to max2
        }
    }
    return max2;
}
