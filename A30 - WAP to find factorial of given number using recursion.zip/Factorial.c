/*
NAME: SANATH SHETTY P
DATE: 19/03/2024
DESCRIPTION: WAP to find factorial of given number using recursion
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./factorial
Enter the value of N : 7

Test Case 2:
Enter the value of N : 5

Test case 3:
Enter the value of N : -1


Test case 4:
Enter the value of N : 0

SAMPLE OUTPUT:
Test Case 1: Factorial of the given number is 5040
Test Case 2: Factorial of the given number is 120
Test case 3: Invalid Input
Test case 4: Factorial of the given number is 1
*/

#include <stdio.h>

// Function declaration
unsigned long long int factorial(int num);

int main()
{
    // Declare a static integer variable 'num' to user input
    int num;

    // Declare a static unsigned long long integer variable 'fact' to store factorial
    unsigned long long int fact = 1;

    // user to enter a number
    printf("Enter the number: ");

    // Read the user input and store it in 'num'
    scanf("%d", &num);

    // If the user enters a number less than 1, ask for input again
    if (num < 0)
    {
        printf("Invalid input"); // Print error
        return 1;
    }

    // Calculate factorial of the entered number using factorial function
    fact = factorial(num);

    // Print the calculated factorial
    printf("Factorial of the given number is %lld", fact);
    return 0;
}

// Function to calculate factorial recursively
unsigned long long int factorial(int num)
{
    // if num is 0 or 1, return 1
    if (num == 1 || num == 0)
    {
        return 1;
    }
    // Else calculate factorial recursively
    else
    {
        return num * factorial(num - 1);
    }
}
