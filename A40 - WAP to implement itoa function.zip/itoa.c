/*
NAME: SANATH SHETTY P
DATE: 30/03/2024
DESCRIPTION: WAP to implement itoa function
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./itoa
Enter the number : 1234

Test Case 2:
user@emertxe] ./itoa

Test Case 3:
user@emertxe] ./itoa
Enter the number : +1234

Test Case 4:
user@emertxe] ./itoa
Enter the number : a1234

SAMPLE OUTPUT:
Test Case 1: Integer to string is 1234
Test Case 2: Integer to string is -1234
Test Case 3: Integer to string is 1234
Test Case 4: Integer to string is 0
*/

#include <stdio.h> // Include standard input/output library

// Function prototype
int itoa(int num, char *str);

int main()
{
    // Variable declaration
    int num, ret;
    // String declaration
    char str[10];
    
    // Prompt user to enter a number
    //printf("Enter the number:");
    // Read the number from user input
    ret = scanf("%d", &num);
    
    // Function call to convert integer to string
    itoa(num, str);
	
    // Display the results
    if(ret == 0)	            
    {    	            
        // If scanf failed to read a number
        printf("Integer to string is %d\n", ret);	            
    }	        
    else	            
    {                   
        // Display the converted string
        printf("Integer to string is %s\n", str);	            
    }
}

// Function definition to convert integer to string
int itoa(int num, char *ptr)
{
    // Variable declaration
    int rev = 0, mod, var, mod1, num1;
            
    num1 = num;
            
    // Handle negative numbers
    if (num < 0)                
    {                    
        *ptr = '-' + 0;                    
        num = -num;                    
        ptr++;                
    }                
    
    // Reverse the digits of the number
    while (num > 0)                   
    {                            
        mod = num % 10;                        
        rev = (rev * 10) + mod;                        
        num = num / 10;                    
    }                
    
    // Convert each digit to character and store it in the string
    while (rev > 0)                    
    {                        
        var = rev % 10;                        
        var = var + '0';                        
        *ptr = var;                        
        ptr++;

        rev = rev / 10;                    
    }
                 
    // Handle trailing zeros
    while (num1)                    
    {                        
        mod1 = num1 % 10;
            
        if (mod1 == 0)                    
        {                        
            *ptr = 0 + '0';
                         
            ptr++;                    
        }            
        else
            break;
            
        num1 = num1 / 10;        
    }         
    
    // Add null terminator to the end of the string
    *ptr = '\0';  
}
