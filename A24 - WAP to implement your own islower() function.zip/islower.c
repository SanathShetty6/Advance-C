/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement your own islower() function
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./c_type_lib
Enter the character: a

Test Case 2:
Enter the character:3

SAMPLE OUTPUT:
Test Case 1: Entered character is lower case alphabet
Test Case 2: Entered character is not lower case alphabet
*/

#include <stdio.h>
//Declare the function 
int my_islower(char);

int main()
{
    char ch;            //Declare the character ch
    int ret;            //Declare the integer
    
    printf("Enter the character:");     //Enter the character
    scanf("%c", &ch);                   //Read the character
    
    ret = my_islower(ch);           //Call the function
    if (ret == 1)                   // print whether character is lower or not
    {
        printf("Entered character is lower case alphabet");    //If ret equal to 1 print it is lower
    }
    else
    {
        printf("Entered character is not lower case alphabet");    //Else print not lower  
    }
}

//Function declaration
int my_islower(char ch)
{
    if( (ch >= 'a' && ch <='z' ) )     //Check the char ch is lower or not
    {
        return 1;       //If true return 1;
    }
    else{
        return 0;       //Else return 0;
    }
}

