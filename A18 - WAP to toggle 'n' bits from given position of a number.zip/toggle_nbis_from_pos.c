/*
NAME: SANATH SHETTY P
DATE: 08/03/2024
DESCRIPTION: WAP to toggle 'n' bits from given position of a number
SAMPLE INPUT:
Test Case 1:
Enter the number: 10
Enter number of bits: 3
Enter the pos: 5

Test Case 2:
Enter the number: 15
Enter number of bits: 2
Enter the pos: 2

SAMPLE OUTPUT:
Test Case 1: Result = 50
Test Case 2: Result =  9
*/

#include <stdio.h>

//Function Declration
int toggle_nbits_from_pos(int, int, int);

int main()
{
    //Declare the integers
    int num, n, pos, res = 0;
    
    //Enter the input
    printf("Enter num, n and val:");
    //Read the input
    scanf("%d%d%d", &num, &n, &pos);
    //Get the toggled bits from position
    res = toggle_nbits_from_pos(num, n, pos);
    //Print the result
    printf("Result = %d\n", res);
    return 0;
}

//Function defination

int toggle_nbits_from_pos(int num,int bit,int pos)
{
    // toggle the bits
    int result =num ^ ~(~0 << bit) << (pos - bit + 1);
    // Return the result
    return result;
}

