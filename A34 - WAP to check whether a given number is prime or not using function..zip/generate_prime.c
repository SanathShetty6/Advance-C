/*
NAME: SANATH SHETTY P
DATE: 20/03/2024
DESCRIPTION: WAP to check whether a given number is prime or not using function.
SAMPLE INPUT:
Test case 1:
user@emertxe]./prime_or_not
Enter a number: 2

Test case 2:
user@emertxe]./prime_or_not
Enter a number: 4

Test case 3:
user@emertxe]./prime_or_not
Enter a number: 101

Test case 4:
user@emertxe]./prime_or_not
Enter a number: 47

Test case 5:
user@emertxe]./prime_or_not
Enter a number: -2

Test case 6:
user@emertxe]./prime_or_not
Enter a number: 25

Test case 7:
user@emertxe]./prime_or_not
Enter a number: 2089

SAMPLE OUTPUT:
Test case 1: 2 is a prime number
Test case 2: 4 is not a prime number
Test case 3: 101 is a prime number
Test case 4: 47 is a prime number
Test case 5: Invalid input
Test case 6: 25 is not a prime number
Test case 7: 2089 is a prime number
*/

#include <stdio.h>
#include <math.h> // Including math.h for sqrt function

// Function prototype for checking prime numbers
int is_prime(int);

int main()
{
    int n;
    
    // Prompt user to enter a number
    //printf("Enter a number: ");
    scanf("%d", &n);
    
    // Check if the input is valid (greater than or equal to 1)
    if (n >= 1)
    {
        // Call the is_prime function to check if the number is prime
        int res = is_prime(n);
        
        // Display the result based on the return value of is_prime
        if (res == 1)
        {
            printf("%d is a prime number",  n);
        }
        else
        {
            printf("%d is not a prime number", n);
        }
    }
    else
    {
        // Display an error message for invalid input
        printf("Invalid input");
    }
    
    return 0;
}

// Function to check if a number is prime
int is_prime(int n)
{
    // 0 and 1 are not prime numbers
    if (n <= 1)
        return 0;
    
    // Iterate from 2 to the square root of n
    for (int i = 2; i <= sqrt(n); i++)
    {
        // If n is divisible by i, it's not prime
        if (n % i == 0)
        {
            return 0;
        }
    }
    
    // If no , n is prime
    return 1;
}

