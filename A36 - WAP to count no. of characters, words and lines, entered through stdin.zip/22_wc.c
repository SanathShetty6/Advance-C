/*
NAME: SANATH SHETTY P
DATE: 25/03/2024
DESCRIPTION: WAP to count no. of characters, words and lines, entered through stdin
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./my_wc
Hello world
Dennis Ritchie
Linux
Character count : 33
Line count : 3
Word count : 5

Test Case 2:
Hello         world
Dennis    Ritchie
Linux
Character count : 39
Line count : 3
Word count : 5
SAMPLE OUTPUT:
*/

#include <stdio.h>

int main()
{
    //Variable declaration
    int line_count = 0, word_count = 0, char_count = 0;
    char ch, temp = ' '; // Initialize temp to space

    // Loop until end of file (EOF) is reached
    while ((ch = getchar()) != EOF)
    {
        char_count++; // Increment character count for every character read

        // Check if the current character is a newline ('\n')
        if (ch == '\n')
        {
            line_count++; // If yes, increment line count
        }

        // Check if the current character is a space (' '), newline ('\n'), or tab ('\t')
        if (ch == ' ' || ch == '\n' || ch == '\t')
        {
            // Check if the previous character was not a space, newline, or tab
            if (temp != ' ' && temp != '\n' && temp != '\t')
            {
                word_count++; // If yes, increment word count
            }
        }
        temp = ch; // Store the current character for the next iteration
    }

    // Output the counts
    printf("Character count : %d\n", char_count);
    printf("Line count : %d\n", line_count);
    printf("Word count : %d\n", word_count);

    return 0;
}
