/*
NAME: SANATH SHETTY P
DATE: 06/03/2024
DESCRIPTION: A12 - WAP to print all primes using Sieve of Eratosthenes method
SAMPLE INPUT:
Test Case 1: A positive number
user@emertxe] ./prime_series
Enter the value of 'n' : 20

Test Case 2 :
Enter the value of 'n' : -20

SAMPLE OUTPUT:
Test Case 1:
The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19
Test Case 2:
Please enter a positive number which is > 1
*/

#include <stdio.h>

int main()
{
    int i, j, num;                          //Declare variable
    printf("Enter the value of 'n' : ");    //Read the number
    scanf("%d", &num);
    if (num > 1)                            //Check number is positive or not
    {
        int arr[num + 1];                   //Declare array

        for (i = 1; i <= num; i++)          // using loop i less than equal num its true is i value increment
 {
        {
            if (arr[num + 1])
                arr[i] = 1;                 //Prime array stored in i index
        }
        for (i = 2; i * i <= num; i++)      // muliplication  lessthan equal to num and i value  increment 
        {
            if (arr[i] != 1)                // prime array not equal to -1 print the value
            {
                for (j = 2 * i; j <= num; j = j + i)    // i=2 to run another loop  to get j value  addition to i value j+=i 
                    arr[j] = -1;              // to assume prime array j index value -1  
            }
        }
        printf("The primes less than or equal to %d are:", num);    // to print the prime contents
        for (i = 2; i <= num; i++)
        {
            if (arr[i] != -1)               // prime array index not equal to j=-1 value
            {
                printf("%d ,", i);          // to print the prime numbers  
    }
            }
        }
    }
    else
    {
        printf("Please enter a positive number which is > 1\n");    // enter number -ve to print the error message
    }
    return 0;
}
