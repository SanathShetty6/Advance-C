/*
NAME: SANATH SHETTY P
DATE: 20/03/20254
DESCRIPTION: WAP to generate negative fibbonacci numbers using recursion
SAMPLE INPUT: 
Test Case 1 :
user@emertxe] ./fibbonacci_series
Enter a number: -8

Test Case 2:
Enter a number: -10

Test Case 3:
Enter a number: -21

Test Case 3:
Enter a number: 21

SAMPLE OUTPUT:
Test Case 1 : 0, 1, -1, 2, -3, 5, -8 
Test Case 2 : 0, 1, -1, 2, -3, 5, -8 
Test Case 3 : 0, 1, -1, 2, -3, 5, -8, 13, -21
Test Case 4 : Invalid input
*/

#include <stdio.h>

// Function declaration for negative_fibonacci
void negative_fibonacci(int, int, int, int);

int main()
{
    // Variable declaration
    int limit;

    //User to enter the limit
    printf("Enter the limit : ");
    scanf("%d", &limit);

    // Initializing variables for Fibonacci sequence
    int first = 1;
    int second = 1;
    int next = 0;

    // Checking if the limit is less than or equal to zero
    if (limit <= 0)
    {
        // If true, call the function to print negative Fibonacci numbers
        negative_fibonacci(limit, first, second, next);
    }
    else
    {
        //If not true, print invalid message
        printf("Invalid input");
    }

    return 0;
}

// Function to print negative Fibonacci numbers up to a given limit
void negative_fibonacci(int limit, int first, int second, int next)
{
    // Printing the current Fibonacci number
    printf("%d, ", next);

    // Updating Fibonacci numbers
    first = second;
    second = next;
    next = first - second;

    // Checking if the next Fibonacci number is within the limit
    if (next >= limit && next <= -1 * limit)
    {
        // If true, recursively call the function
        negative_fibonacci(limit, first, second, next);
    }
}

