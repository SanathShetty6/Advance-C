/*
NAME: SANATH SHETTY P
DATE: 21/02/2024
DESCRIPTION: WAP to generate positive Fibonacci numbers
SAMPLE INPUT:
Test Case 1 :
Enter a number: 8
Test Case 2:
Enter a number: 10
Test Case 3:
Enter a number: 21
Test Case 4:
Enter a number: -21

SAMPLE OUTPUT:
Test Case 1 :
0 1 1 2 3 5 8
Test Case 2:
0 1 1 2 3 5 8
Test Case 3:
0 1 1 2 3 5 8 13 21
Test Case 4:
Invalid input
*/
#include <stdio.h>

int main()
{
    int i,num;
    int first=0,second=1,next=0;        //Declare the integer
    printf("Enter a number : ");        //Enter the input
    scanf("%d", &num);

    if(num>=0)                          //Check the number is positive or not
    {
    while(next <=num) 
    {                                   //Read the number in loop
        printf("%d ", next);            //Print the output
        first=second;                   //Assign second value to first
        second=next;                    //Assign next value to second
        next=first+second;              //Add first and second       
    }
    }
    else{
        printf("Invalid input");        //If num less than zero print error
    }

printf("\n");
    return 0;
}

