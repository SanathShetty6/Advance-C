/*
NAME: SANATH SHETTY P
DATE: 18/03/2024
DESCRIPTION: WAP to remove duplicate elements in a given array
SAMPLE INPUT: 
Test Case 1:
Enter the size: 5
Enter elements into the array: 5 1 3 1 5

Test Case 2:
Enter the size: 5
Enter elements into the array: 2 1 1 1 5

SAMPLE OUTPUT:
Test Case 1: After removing duplicates: 5 1 3
Test Case 2: After removing duplicates: 2 1 5
*/

#include <stdio.h>

void fun(int arr1[], int size, int arr2[], int *new_size);

int main()
{
    //Declare the integer
    int size, i;

    //Enter the size
    printf("Enter the size: ");

    //Read the size
    scanf("%d", &size);

    //Declare the array and new size
    int arr1[size], arr2[size];
    int new_size=0;

    //Enter the elements of array
    printf("Enter the elements for array:");
    for ( i = 0 ; i < size ; i++)
    {
        scanf("%d", &arr1[i]);
    }

    // Call function to remove duplicates
    fun(arr1, size, arr2, &new_size);

    //Print the new array after deleting
    printf("After removing duplicates: ");
    for(i = 0 ; i < new_size ; i++)
    {
        printf("%d ", arr2[i]);
    }
    printf("\n");
    return 0;
}
//Function defination
void fun(int arr1[], int size, int arr2[], int *new_size)
{
    //Declare the integers
    int i,j;

    //Remove the duplicate elements in array
    for (i = 0; i < size; i++) 
    {
        //Set flag equal to zero
        int flag=0;
        for (j = 0; j < *new_size; j++) 
        {
            //Compare both array elements
            if (arr1[i] == arr2[j]) 
            {
                //If both are equal set the flag equal to 1
                flag = 1;
                break;
            }
        }
        //If flag is not equal copy the array 1 element to new array
        if (!flag) 
        {
            arr2[*new_size] = arr1[i];
            //Increment the size
            (*new_size)++;
        }
    }
}

