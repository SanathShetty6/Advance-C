/*
NAME: SANATH SHETTY P
DATE: 26/02/20245
DESCRIPTION: WAP to print triangle pattern as shown below
SAMPLE INPUT:
Test Case 1:
Enter the number: 4
Test Case 2:
Enter the number: 5
SAMPLE OUTPUT:
Test Case 1:
1 2 3 4
5     6
7 8
9
Test Case 2:
1 2 3 4 5
6       7
8    9
10 11
12

*/

#include <stdio.h>

int main()
{
    int n;
    int count = 1; // Declare the input

    // Enter the input
    printf("Enter the number: ");
    scanf("%d", &n);

    // Loop to print the triangle pattern
    for (int i = 1; i <= n; i++)            //loop i for row 
    {
        for (int j = i; j <= n; j++)        //loop j for column
        {
            if (i==j || i == 1 || j==n)     
            {
                printf("%d ", count);        //Print the count
                count++;                    //Increment the count
            }
 
            else
            {
                printf(" ");                //Else print space
            }
        }
        
            printf("\n");
        
    }

    return 0;
}
