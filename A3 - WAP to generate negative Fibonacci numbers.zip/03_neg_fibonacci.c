/*
NAME: SANATH SHETTY P
DATE: 
DESCRIPTION: 
SAMPLE INPUT:
SAMPLE OUTPUT:
*/
#include <stdio.h>

int main()
{
    int num;
    int first=1,second=1,next=0;            //Declare the integer
    printf("Enter a number : ");            //Enter the input
    scanf("%d", &num);

    if(num <= 0)                            //Check the number is positive or not
    {
    while(next >= num  && next <=-1*num)    //Read the number in loop
    {
        printf("%d ", next);                //Print the output
        first = second;                     //Assign second value to first
        second = next;                      //Assign next value to second
        next = first-second;                //Subtract first and second       
    }
    }
    else{
        printf("Invalid input");            //If num greater than zero print error
    }

 printf("\n");
    return 0;
}


