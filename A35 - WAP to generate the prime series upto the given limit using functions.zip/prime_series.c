/*
NAME: SANATH SHETTY P
DATE: 21/03/2024
DESCRIPTION: WAP to generate the prime series upto the given limit using functions
SAMPLE INPUT: 
Test case 1: 
user@emertxe]./prime_or_not
Enter a number: 2

Test case 2: 
user@emertxe]./prime_or_not
Enter a number: 4

Test case 3: 
user@emertxe]./prime_or_not
Enter a number: 20

Test case 5: 
user@emertxe]./prime_or_not
Enter a number: -2

Test case 6: 
user@emertxe]./prime_or_not
Enter a number: 1

SAMPLE OUTPUT:
Test case 1: 2
Test case 2: 2 3
Test case 3: 2 3 5 7 11 13 17 19
Test case 5: Invalid input
Test case 6: Invalid input
*/

#include <stdio.h>

// Function prototype for checking prime numbers
int is_prime(int);

// Function prototype for generating prime numbers up to a given limit
void generate_prime(int);

// Main function
int main()
{
    int limit;

    // Prompt user to enter the limit
    //printf("Enter the limit: ");
    scanf("%d", &limit);

    // Check if the limit is greater than 1
    if (limit > 1)
    {
        // If yes, generate prime numbers up to the given limit
        generate_prime(limit);
    }
    else
    {
        // If no, display an error message
        printf("Invalid input\n");
    }

    return 0;
}

// Function to check if a number is prime
int is_prime(int n)
{
    // 0 and 1 are not prime numbers
    if (n <= 1)
        return 0;
    
    // Check divisibility up to the square root of n
    for (int i = 2; i * i <= n; i++)
    {
        // If n is divisible by i, it's not prime
        if (n % i == 0)
        {
            return 0;
        }
    }
    // If no , n is prime
    return 1;
}

// Function to generate prime numbers up to the given limit
void generate_prime(int limit)
{
    // Print a message indicating the limit
    //printf("Prime series up to %d: ", limit);
    
    // Iterate through numbers from 2 to the limit
    for (int i = 2; i <= limit; i++)
    {
        // If the current number is prime, print it
        if (is_prime(i))
            printf("%d ", i);
    }
    printf("\n");
}
