/*
NAME: SANATH SHETTY P
DATE: 30/03/2024
DESCRIPTION: WAP to reverse the given string using iterative method
SAMPLE INPUT: 
Test Case 1:
user@emertxe] ./str_rev

Test Case 2:
user@emertxe] ./str_rev
Enter a string : EMERTXE
Reverse string is : EXTREME
SAMPLE OUTPUT:
Test Case 1: Reverse string is : dlroW olleH
Test Case 2: Enter a string : Hello World
*/

#include <stdio.h>

// Function prototype
void reverse_iterative(char str[]);

int main()
{
    char str[30];
    
    // Prompt user to enter a string
    printf("Enter any string : ");
    // Read the string until newline character
    scanf("%[^\n]", str);
    
    // Reverse the input string
    reverse_iterative(str);
    
    // Display the reversed string
    printf("Reversed string is %s\n", str);
}

// Function to reverse a string iteratively
void reverse_iterative(char *str)
{
    // Find the length of the string
    int length = 0;
    while(str[length] != '\0')
    {
        length++;
    }
    
    int len = length;
    
    // Swap characters from beginning to middle of the string
    for (int i = 0; i < len / 2; i++)
    {
        // Swap characters
        int temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
}
