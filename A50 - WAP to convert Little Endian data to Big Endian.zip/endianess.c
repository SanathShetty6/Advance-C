/*
NAME: SANATH SHETTY P
DATE: 10/04/2024
DESCRIPTION: WAP to convert Little Endian data to Big Endian
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./endianness
Enter the size: 2
Enter any number in Hexadecimal: ABCD

Test Case 2:
Enter the size: 4
Enter any number in Hexadecimal: 12345678

SAMPLE OUTPUT:
Test Case 1: After conversion CDAB
Test Case 2: After conversion 78563412
*/

#include <stdio.h>

int main() {
    // Variable declaration
	int size, num; 
    char temp;

    // Read size from user
	printf("Enter the size (2 for short, 4 for integer): ");
	scanf("%d", &size);

    // Read hexadecimal value from user
	printf("Enter any number in Hexadecimal: ");
	scanf("%X", &num); 

    // Pointer variable storing the address of the variable number
	char *ptr = (char *)&num; 

    // Swap bytes for short integer (2 bytes)
	if (size == 2) {
		temp = *ptr;
		*ptr = *(ptr+1);
		*(ptr+1) = temp;
	}
    // Swap bytes for integer (4 bytes)
    else if (size == 4) {
		char temp1;
		temp = *ptr;
		*ptr = *(ptr+3);
		*(ptr+3) = temp;        
		temp1 = *(ptr+1);
		*(ptr+1) = *(ptr+2);
		*(ptr+2) = temp1;
	}

    // Print the hexadecimal number after conversion
	printf("After conversion: %X\n", num); 
	
    return 0;
}
