/*
NAME: SANATH SHETTY P
DATE: 09/04/2024
DESCRIPTION: WAP to print all possible combinations of given string.
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./combinations
Enter a string: abc

Test Case 2:
Enter a string: abb

SAMPLE OUTPUT:
Test Case 1:
All possible combinations of given string :abc
acb
bca
bac
cab
cba

Test Case 2:
Error: please enter distinct characters.

*/

#include<stdio.h>

// Function prototypes
void combination(char [], int, int);
int my_strlen(char []);

int main() {
    // string and variable declaration
    char str[100];
    int n, i;

    // read string from user
    printf("Enter a string: ");
    scanf("%100[^\n]", str);

    // Calculate the length of the string
    n = my_strlen(str);

    // To check whether unique characters are entered or not
    int flag = 0;
    for (i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (str[i] == str[j]) {
                flag = 1;
                break;
            }
        }
    }

    // If unique characters entered then calling combination function
    if (flag != 1) {
        combination(str, 0, n - 1);
    } else {
        printf("Error: please enter distinct characters.\n");
    }

    return 0;
}

// Function to calculate the length of a string
int my_strlen(char str[]) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

// Function to find all possible combinations of a string
void combination(char str[], int first, int last) {
    // Variable declaration
    int fact = 1, i = 1;

    // First need to find factorial of length of string to print all combinations of the string
    while (i <= last + 1) {
        fact = fact * i;
        i++;
    }

    i = 0;

    printf("All possible combinations of given string :");

    char temp;

    while (i < fact) {
        // Display the results
        printf("%s\n", str);

        // To alternatively swap 2 different indexes for each iteration
        if (i % 2 == 0) {
            temp = str[first + 1];
            str[first + 1] = str[last];
            str[last] = temp;
        } else {
            temp = str[first];
            str[first] = str[last];
            str[last] = temp;
        }
        i++;
    }
}
