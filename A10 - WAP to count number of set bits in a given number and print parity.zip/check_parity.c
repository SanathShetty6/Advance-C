/*
NAME: SANATH SHETTY P
DATE: 27/02/2024
DESCRIPTION: WAP to count number of set bits in a given number and print parity
SAMPLE INPUT:
Test Case 1:
Enter the number : 7
Test Case 2:
Enter the number : 15
Test Case 3:
Enter the number : 6

SAMPLE OUTPUT:
Test Case 1:
Number of set bits = 3
Bit parity is Odd
Test Case 2:
Number of set bits = 4
Bit parity is Even
Test Case 3:
Number of set bits = 2
Bit parity is Even
*/

#include <stdio.h>

int main()
{
    int num,i,n=7,count=0;

    //Enter the input
    printf("Enter the number : ");
    scanf("%d", &num);

//Read the number 
    for(i=0;i<=n;i++)
    {
        //Shift leftwise 1 by one to num and compare
        if((num & (1 << i)) !=0 )
        {
            count++;            //Increment count
        }      
    }
    printf("Number of set bits = %d\n", count);     //Print the output

//Check even or odd parity
    if( count % 2 == 0)
    {
        printf("Bit parity is Even\n");
    }
    else
    {
        printf("Bit parity is Odd\n");
    }
    return 0;
}

/*#include <stdio.h>

int main()
{   
    int n, i, count=0;
    printf("Enter the number :\n"); // n from user
    scanf("%d", &n);
    
    for(i = 0; i < 7; i++ ) // for int 32 bit
    {
        if(n & ( 1 << i )) // 1 left shift 1 to check how many set bit
        {
            count++; // count set bit
        }
    } 
    printf("Number of set bits =  %d\n", count); 
    if( count % 2 == 0) // check set bit parity is even or odd
    {
        printf("Bit parity is Even");
    }
    else
    {
         printf("Bit parity is Odd");
    }
    return 0;
}
*/
