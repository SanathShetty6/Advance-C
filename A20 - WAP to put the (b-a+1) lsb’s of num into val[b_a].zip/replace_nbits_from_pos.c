/*
NAME: SANATH SHETTY P
DATE: 11/03/2024
DESCRIPTION: WAP to put the (b-a+1) lsb’s of num into val[b:a]
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./bit_ops
Enter the value of 'num' : 11
Enter the value of 'a' : 3
Enter the value of 'b' : 5
Enter the value of 'val': 174

SAMPLE OUTPUT:
Test Case 1: Result : 158
*/

#include <stdio.h>
//Function declaration
int replace_nbits_from_pos(int, int, int, int);

int main()
{
    int num, a, b, val, res = 0;            //Declare the integers

    printf("Enter num, a, b, and val:");    //Enter the input
    scanf("%d%d%d%d", &num, &a, &b, &val);  //Read the input
    if (a <= b && b <= 31)                  //Check the input 'a' is less than 'b' and 'b' less than 31 
    {
        b = b - a + 1;                      //Call replace_nbits_from_pos function by passing val, b - a + 1
        res = replace_nbits_from_pos(num, a, b, val);   //Call the function
    }
    else{
        printf("invalid output : please pass the value a and b  less than or equal to 31\n");  // a and b value above 31 to print the error message
    }
    printf("Result = %d\n", res);   //Print the output
}

//Function defination
int replace_nbits_from_pos(int num, int a, int b, int val)
{
    int res = ((num & ((1 << a)-1)) << a) | (val & (~(((1 << a)-1) << a)));                     // to replace num bits from the postion

    return res; //Return to res
}