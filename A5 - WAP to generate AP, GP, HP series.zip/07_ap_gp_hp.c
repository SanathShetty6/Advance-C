/*
NAME: SANATH SHETTY P
DATE:26/02/2024 
DESCRIPTION:WAP to generate AP, GP, HP series
SAMPLE INPUT:
Test Case 1:
Enter the First Number 'A': 2
Enter the Common Difference / Ratio 'R': 3
Enter the number of terms 'N': 5
Test Case 2:
Enter the First Number 'A': 2
Enter the Common Difference / Ratio 'R': 3
Enter the number of terms 'N': -5

SAMPLE OUTPUT:
Test Case 1:
AP = 2, 5, 8, 11, 14
GP = 2, 6, 18, 54, 162
HP = 0.500000, 0.200000, 0.125000, 0.090909, 0.071428
Test Case 2:
Invalid input
*/

#include <stdio.h>

int main()
{
	int i,a,r,n;
    int ap,gp,pow=1;
    float hp;
	printf("Enter the First Number 'A':");
	scanf("%d", &a);
    printf("Enter the Common Difference / Ratio 'R':");
	scanf("%d", &r);
    printf("Enter the number of terms 'N':");
	scanf("%d", &n);

    
    if(n >= 1) // checking the number positive or not
    {
        printf("AP = ");
        ap = a;
        printf("%d", ap);

        for(i = 1; i <= n - 1; i++) // for loop
        {
            ap = ap + r;
            printf(", %d", ap);
        }
        printf("\n");

        printf("GP = ");
        gp = a;
        printf("%d", gp);

        for(i = 1; i <= n - 1; i++) // for loop
        {
            pow = pow * r;
            gp = a * pow;
            printf(", %d", gp);
        }
        printf("\n");

        printf("HP = ");

        ap = a;
        hp = 1.0 / ap; // type casting for float value
        printf("%f", hp);

        for(i = 1; i <= n - 1; i++) // for loop
        {
            ap = ap + r;
            hp = 1.0 / ap; // type casting for float value
            printf(", %f", hp);
        }
        printf("\n");


    }
    else
        printf("Invalid input\n");


    return 0;
}

