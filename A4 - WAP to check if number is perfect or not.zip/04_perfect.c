/*
NAME: SANATH SHETTY P
DATE: 
DESCRIPTION:
SAMPLE INPUT:
Test Case 1:
Enter a number: 6
Test Case 2:
Enter a number: 10
Test Case 3:
Enter a number: -1

SAMPLE OUTPUT:
Test Case 1:
Yes, entered number is perfect number
Test Case 2:
No, entered number is not a perfect number
Test Case 3:
Error : Invalid Input, Enter only positive number
*/

#include <stdio.h>

int main()
{
    int num;                        //Declare the integer
    int i,sum=0;
    printf("Enter a number: ");     //Enter the input
    scanf("%d", &num);

    if(num >= 0)                    //Check the number is positive or not
    {
        for(i=1;i<=num/2;i++)       //Read the number and divide by 2
        {
            if(num%i==0)            //Check the number equal to 0
            {
                sum+=i;             //If equal to zero add the number
            }
        
        }
        if(sum==num)                //If sum equal to input
        {
            printf("Yes, entered number is perfect number");    //Print number is perfect
        }
        else
        {
            printf("No, entered number is not a perfect number");   //Print number is not perfect
        }
    }
    else
    {
        printf("Error : Invalid Input, Enter only positive number");    //If number is negative print error message
    }

    return 0;
}

