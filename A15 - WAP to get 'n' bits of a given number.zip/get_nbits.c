/*
NAME: SANATH SHETTY P
DATE: 02/03/2024
DESCRIPTION:
SAMPLE INPUT:
Test Case 1:
Enter the number: 10
Enter number of bits: 3

Test Case 2:
Enter the number: 15
Enter number of bits: 2

SAMPLE OUTPUT:
Test Case 1: Result = 2
Test Case 2: Result = 3
*/

#include <stdio.h>

//Function declaration
#include <stdio.h>

int get_nbits(int, int);

int main()
{
    //Declare the integer
    int num, n, res = 0;
    //Enter the input
    printf("Enter num and n:");
    //Read the input
    scanf("%d%d", &num, &n);
    //Get n bits and store in result
    res = get_nbits(num, n);
    //Print the output
    printf("Result = %d\n", res);
}
//Function defining
int get_nbits(int num1, int num2)
{
    int mask=(1<<num2)-1; //Get the mask value
    int result=num1 & mask; //Extract the n bit
}

