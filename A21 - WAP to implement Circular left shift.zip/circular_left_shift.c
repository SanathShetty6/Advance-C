/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement Circular left shift
SAMPLE INPUT: 
Test Case 1:
user@emertxe] ./bit_ops

Enter num: 12
Enter n : 3

Test Case 2: 
Enter num: -2
Enter n : 3

SAMPLE OUTPUT:
Test Case 1: Result in Binary: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0
Test Case 2: Result in Binary: 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 0 1 1 1

*/

#include <stdio.h>
//Declare the functions
int circular_left(int, int);
int print_bits(int);

int main()
{
    int num, n, ret;                    //Declare the integer
    
    //printf("Enter the num:");           //Enter the num value
    scanf("%d", &num);                  //Read the input value
    
    //printf("Enter n:");                 //Enter n value to shift number of times
    scanf("%d", &n);                    //Read the input 
    
    ret = circular_left(num, n);        //Call function to perform circular shift
    printf("Result in Binary: ");
    print_bits(ret);                    //Call function to print the bits
}

int circular_left(int num, int n)
{
    unsigned int a =num;
    int ret=(num << n) | (a >> (32-n));          //Perform Circular left shift
    return ret; 
}

int print_bits(int ret)
{
    for( int i = 31  ; i >= 0; i--)            // loop printing each binary value msb to lsb
    { 
        if( ret & 1 << i)                      // mulitiple ret value & lrft shift with i value   
            
            printf("1 ");                      //If condition is true print 1
         
        else

            printf("0 ");                      //Else print 0.
           
    }

}
