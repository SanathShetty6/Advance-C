/*
NAME: SANATH SHETTY P
DATE: 02/03/2024
DESCRIPTION: WAP to replace 'n' bits of a given number
SAMPLE INPUT:
Test Case 1:
Enter the number: 10
Enter number of bits: 3
Enter the value: 12
Test Case 2:
Enter the number: 15
Enter number of bits: 2
Enter the value: 1
Result =  13
SAMPLE OUTPUT:
Test Case 1: Result = 12
Test Case 2: Result =  13
*/

#include <stdio.h>
//Functio declaration
int replace_nbits(int, int, int);

int main()
{
    //Integer declaration
    int num, n, val, res = 0;
    //Enter the input
    printf("Enter num, n and val:");
    //Read the input
    scanf("%d%d%d", &num, &n, &val);
    //Get the replace bit and store in result
    res = replace_nbits(num, n, val);
    //Print the result
    printf("Result = %d\n", res);
          return 0;
}
//Function defination
int replace_nbits(int num,int n,int val)
{
    int mask,value,result;
    //Create a mask
    mask=~((1<<n)-1);
    //Mask last n bits
    num=num&mask;
    value=val & ((1<n)-1);
    //Replace the valued bits in num
    num=num | val;
    return num;



}

