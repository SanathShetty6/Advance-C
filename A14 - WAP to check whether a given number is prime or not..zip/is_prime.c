/*
NAME: SANATH SHETTY P
DATE: 29/02/2024
DESCRIPTION: WAP to check whether a given number is prime or not.
SAMPLE INPUT:
Test case 1: 
Enter a number: 2

Test case 2: 
Enter a number: 4

Test case 3: 
Enter a number: 101

Test case 4: 
Enter a number: 47


Test case 5: 
Enter a number: -2


Test case 6: 
Enter a number: 25

Test case 7: 
Enter a number: 2089

SAMPLE OUTPUT:
Test case 1: 
2 is a prime number
Test case 2: 
4 is not a prime number
Test case 3:
101 is a prime number 
Test case 4: 
47 is a prime number
Test case 5: 
Invalid input
Test case 6: 
25 is not a prime number
Test case 7: 
2089 is a prime number

*/

#include <stdio.h>

int main()
{

	int num, i, Prime = 1;

	//printf("Enter a number: ");
	scanf("%d", &num);

	// Check for invalid input
	if (num <= 1)
	{
		printf("Invalid input\n");
		return 0;
	}

	// Check for prime
	for (i = 2; i <= num / 2; ++i)
	{
		if (num % i == 0)
		{
			Prime = 0;
			
		}
	}

	// Print result
	if (Prime)
		printf("%d is a prime number", num);
	else
		printf("%d is not a prime number", num);

	return 0;
}

