/*
NAME: SANATH SHETTY P
DATE: 01/04/2024
DESCRIPTION: WAP to check given string is Pangram or not
SAMPLE INPUT:
Test Case 1:
Enter the string: The quick brown fox jumps over the lazy dog

Test Case 2:
Enter the string: The quick brown fox jumps over the dog
The Entered String is not a Pangram String
SAMPLE OUTPUT:
Test Case 1: The Entered String is a Pangram String
Test Case 2: The Entered String is not a Pangram String
*/

#include <stdio.h>

// Function prototype
int pangram(char[]);

// Main function
int main()
{
    // Declare an array to store the input string
    char str[100];

    // Prompt the user to enter a string
    printf("Enter the string: ");

    // Read the string entered by the user
    scanf("%[^\n]", str);

    // Check if the entered string is a pangram or not and print the result
    if (pangram(str))
    {
        printf("The Entered String is a Pangram string");
    }
    else
    {
        printf("The Entered String is not a Pangram String");
    }

    return 0;
}

// Function to check if the string is a pangram or not
int pangram(char str[])
{
    // Initialize an array to store the presence of each alphabet
    int alph[26] = {0};

    // Iterate through the string
    for (int i = 0; str[i] != '\0'; i++)
    {
        // Get the current character
        char ch = str[i];

        // Check if the character is an uppercase alphabet
        if (ch >= 'A' && ch <= 'Z')
        {
            // Mark the presence of the alphabet in the array
            alph[ch - 'A'] = 1;
        }
        // Check if the character is a lowercase alphabet
        else if (ch >= 'a' && ch <= 'z')
        {
            // Mark the presence of the alphabet in the array
            alph[ch - 'a'] = 1;
        }
    }

    // Check if all alphabets are present in the array
    for (int i = 0; i < 26; i++)
    {
        if (alph[i] == 0)
        {
            // If any alphabet is missing, return 0 (false)
            return 0;
        }
    }

    // If all alphabets are present, return 1 (true)
    return 1;
}
