/*
NAME: SANATH SHETTY P
DATE: 05/04/2024
DESCRIPTION: WAP to implement strtok function
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./my_strtok
Enter string1 : Bangalore;;::---Chennai:;Kolkata:;Delhi:-:Mumbai
Enter string2 : ;./-:

Test Case 2:
user@emertxe] ./my_strtok
Enter string1 : -;Bangalore;;::---Chennai:;Kolkata:;Delhi:-
Enter string2 : ;./-:

SAMPLE OUTPUT:
Test Case 1:
Tokens :
Bangalore
Chennai
Kolkata
Delhi
Mumbai 

Test Case 2:
Tokens :
Bangalore
Chennai
Kolkata
Delhi
*/

#include <stdio.h>
#include <string.h>
#include <stdio_ext.h> // For __fpurge function

// Function prototype
char *my_strtok(char str[], const char delim[]);

int main()
{
    char str[50], delim[50];

    // Prompt user to enter the string
    printf("Enter the string: ");
    scanf("%s", str); // Read the string

    __fpurge(stdout); // Clear the input buffer

    // Prompt user to enter the delimiter
    printf("Enter the delimiter: ");
    scanf("\n%s", delim); // Read the delimiter

    __fpurge(stdout); // Clear the input buffer

    // Tokenize the string and display the tokens
    char *token = my_strtok(str, delim);
    printf("Tokens :\n");

    while (token)
    {
        printf("%s\n", token);
        token = my_strtok(NULL, delim);
    }
}

// Function to tokenize a string
char *my_strtok(char str[], const char delim[])
{
    static int i; // Static variable to keep track of position in the string
    static char *temp; // Static variable to remember the string
    int len = i, j;

    if (str != NULL)
    {
        temp = str; // If str is not NULL, initialize temp with str
    }

    // Iterate through the string
    while (temp[i] != '\0')
    {
        j = 0;
        // Iterate through the delimiter characters
        while (delim[j] != '\0')
        {
            if (delim[j] == temp[i])
            {
                temp[i] = '\0'; // Replace delimiter with null terminator
                i++;
                if (temp[len] != '\0')
                {
                    return (&temp[len]); // Return pointer to token
                }
                else
                {
                    len = i;
                    i--;
                    break;
                }
            }
            j++;
        }
        i++;
    }
    // Check if end of string is reached
    if (temp[len] == '\0')
    {
        return NULL; // If end of string is reached, return NULL
    }
    else
    {
        return (&temp[len]); // Return pointer to token
    }
}
