/*
NAME: SANATH SHETTY P
DATE: 11/04/2024
DESCRIPTION: WAP to find the product of given matrix.
SAMPLE INPUT:
Test case1:
user@emertxe] ./transpose_product
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :3
1      2      3
1      2      3
1      2      3
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :

1      1     1
2      2     2
3      3     3

Test case 2:
user@emertxe] ./transpose_product
Enter number of rows : 3
Enter number of columns : 3
Enter values for 3 x 3 matrix :
1      2      3
1      2      3
1      2      3
Enter number of rows : 2
Enter number of columns : 3

SAMPLE OUTPUT:
Test Case 1:
Product of two matrix :
14      14      14
14      14      14
14      14      14

Test case 2: Matrix multiplication is not possible
*/

#include <stdio.h>
#include <stdlib.h>

int matrix_mul(int **, int, int, int **, int, int, int **, int, int);

int main() {
    int rows_a, cols_a, rows_b, cols_b;

    // Input number of rows and columns for matrix A
    //printf("Enter number of rows for matrix A: ");
    scanf("%d", &rows_a);
    //printf("Enter number of columns for matrix A: ");
    scanf("%d", &cols_a);

    // Dynamically allocate memory for matrix A
    int **mat_a = (int **)malloc(rows_a * sizeof(int *));
    for (int i = 0; i < rows_a; i++) {
        mat_a[i] = (int *)malloc(cols_a * sizeof(int));
    }

    // Input values for matrix A
    //printf("Enter values for matrix A:\n");
    for (int i = 0; i < rows_a; i++) {
        for (int j = 0; j < cols_a; j++) {
            scanf("%d", &mat_a[i][j]);
        }
    }

    // Input number of rows and columns for matrix B
    //printf("Enter number of rows for matrix B: ");
    scanf("%d", &rows_b);
    //printf("Enter number of columns for matrix B: ");
    scanf("%d", &cols_b);

    // Check if multiplication is possible
    if (cols_a != rows_b) {
        printf("Matrix multiplication is not possible\n");

        // Free dynamically allocated memory for matrix A
        for (int i = 0; i < rows_a; i++) {
            free(mat_a[i]);
        }
        free(mat_a);

        return 1; // Exit the program with error code 1
    }

    // Dynamically allocate memory for matrix B
    int **mat_b = (int **)malloc(rows_b * sizeof(int *));
    for (int i = 0; i < rows_b; i++) {
        mat_b[i] = (int *)malloc(cols_b * sizeof(int));
    }

    // Input values for matrix B
    //printf("Enter values for matrix B:\n");
    for (int i = 0; i < rows_b; i++) {
        for (int j = 0; j < cols_b; j++) {
            scanf("%d", &mat_b[i][j]);
        }
    }

    // Dynamically allocate memory for result matrix
    int **result = (int **)malloc(rows_a * sizeof(int *));
    for (int i = 0; i < rows_a; i++) {
        result[i] = (int *)malloc(cols_b * sizeof(int));
    }

    // Perform matrix multiplication
    matrix_mul(mat_a, rows_a, cols_a, mat_b, rows_b, cols_b, result, rows_a, cols_b);

    // Display result matrix
    printf("Product of two matrix:\n");
    for (int i = 0; i < rows_a; i++) {
        for (int j = 0; j < cols_b; j++) {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }

    // Free dynamically allocated memory for matrices
    for (int i = 0; i < rows_a; i++) {
        free(mat_a[i]);
    }
    free(mat_a);

    for (int i = 0; i < rows_b; i++) {
        free(mat_b[i]);
    }
    free(mat_b);

    for (int i = 0; i < rows_a; i++) {
        free(result[i]);
    }
    free(result);

    return 0;
}

// Function to perform matrix multiplication
int matrix_mul(int **mat_a, int rows_a, int cols_a, int **mat_b, int rows_b, int cols_b, int **result, int rows_result, int cols_result) {
    // Perform multiplication
    for (int i = 0; i < rows_a; i++) {
        for (int j = 0; j < cols_b; j++) {
            result[i][j] = 0;
            for (int k = 0; k < cols_a; k++) {
                result[i][j] += mat_a[i][k] * mat_b[k][j];
            }
        }
    }

    return 0;
}
