/*
NAME: SANATH SHETTY P
DATE: 26/02/2024
DESCRIPTION:WAP to print the numbers in X format as shown below
SAMPLE INPUT:
Test Case 1:
Enter the number: 4
Test Case 2:
Enter the number: 5
SAMPLE OUTPUT:
Test Case 1:
1  4
 23
 23
1  4
Test Case 2:
1   5
 2 4
  3
 2 4
1   5
*/

#include <stdio.h>

int main()
{
    int i,j,num;
    printf("Enter the number : ");
    scanf("%d", &num);
    for(i=1;i<=num;i++){
        for(j=1;j<=num;j++)
        {
            if((i==j) || (i+j==num+1))
            {
                printf("%d", j);
            }
            else
            {
               printf(" "); 
            }
        }
        printf("\n");
    }
    return 0;
}


