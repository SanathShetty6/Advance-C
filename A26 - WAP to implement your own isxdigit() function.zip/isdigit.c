/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement your own isxdigit() function
SAMPLE INPUT: 
Test Case 1:
user@emertxe] ./is_xdigit
Enter the character: a

Test Case 2:
user@emertxe] ./is_xdigit
Enter the character:3

Test Case 3:
user@emertxe] ./is_xdigit
Enter the character:G

SAMPLE OUTPUT:
Test Case 1: Entered character is an hexadecimal digit
Test Case 2: Entered character is  an hexadecimal digit
Test Case 3: Entered character is not an hexadecimal digit
*/

#include <stdio.h>
//Function declaration
int is_xdigit(char);

int main()
{
    char ch;        //Declare the character ch
    short ret;      //Declare short integer return
    
    printf("Enter a character: ");      //Enter the character
    scanf("%c", &ch);                   //Read the character
    
    ret = is_xdigit(ch);                //Call the function
       if (ret == 1)                   // print whether return value equal to zero or not
    {
        printf("Entered character is an hexadecimal digit");    //If ret equal to 1 print it is hexadecimal
    }
    else
    {
        printf("Entered character is not an hexadecimal digit");    //Else print not hexadecimal
    }
}

//Function defination
int is_xdigit(char ch)
{
    if( (ch >= '0' && ch <='9' ) || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F'))     //Check the char ch is between these  numbers
    {
        return 1;       //If true return 1;
    }
    else{
        return 0;       //Else return 0;
    }
}

