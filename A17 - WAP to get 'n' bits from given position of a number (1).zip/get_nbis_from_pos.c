/*
NAME: SANATH SHETTY P
DATE: 05/03/2024
DESCRIPTION: WAP to get 'n' bits from given position of a numberVirtual programming lab
SAMPLE INPUT:
Test Case 1:

Enter the number: 12

Enter number of bits: 3

Enter the pos: 4

Result = 3

Test Case 2:

Enter the number: 15

Enter number of bits: 2

Enter the pos: 2

Result =  3
SAMPLE OUTPUT:
*/
#include <stdio.h>
//Function declaration
int get_nbits_from_pos(int, int, int);

int main()
{
    //Declare the integer
    int num, n, pos, res = 0;
    //enter the input from the integer
    printf("Enter num, n and val:");
    //Read the input
    scanf("%d%d%d", &num, &n, &pos);
    //Get the nbits from position and store in result
    res = get_nbits_from_pos(num, n, pos);
    //Print the output
    printf("Result = %d\n", res);
    return 0;
}

//Function defination

int get_nbits_from_pos(int num,int bit,int pos)
{
    
    int shift = num >> (pos - bit + 1);
    // Use bitwise AND with a bitmask of 'n' bits to extract those bits
    int result = shift & ((1 << bit) - 1);
    // Return the extracted bits
    return result;
}

