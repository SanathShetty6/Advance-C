/*
NAME: SANATH SHETTY P
DATE: 27/03/2024
DESCRIPTION:  WAP to implement atoi function
SAMPLE INPUT:
est Case 1 :
Enter a numeric string: 12345
String to integer is 12345

Test Case 2 :
Enter a numeric string: -12345
String to integer is -12345

Test Case 3 :
Enter a numeric string: +12345
String to integer is 12345

Test Case 4 :
Enter a numeric string: +-12345
String to integer is 0

Test Case 5 :
Enter a numeric string: 12345-
String to integer is 12345

Test Case 6 :
Enter a numeric string: abcd12345
String to integer is 0

Test Case 7 :
Enter a numeric string: 12345abcd
String to integer is 12345
SAMPLE OUTPUT:
*/

#include <stdio.h>

// Function prototype
int my_atoi(const char[]);

// Main function
int main()
{
    // Declare an array to store the input string
    char str[20];

    // Prompt the user to enter a numeric string
    printf("Enter a numeric string : ");

    // Read the string entered by the user
    scanf("%s", str);

    // Convert the string to an integer using custom atoi function and print the result
    printf("String to integer is %d\n", my_atoi(str));
}

// Function to convert a string to an integer
int my_atoi(const char *str)
{
    // Initialize variables
    int res = 0; // Resulting integer
    int i = 0;   // Index for iterating through the string
    int flag = 1; // Flag to handle sign, initialized to positive by default

    // Skip leading whitespace characters
    while (str[i] == ' ')
    {
        i++;
    }

    // Handle sign
    if (str[i] == '+' || str[i] == '-')
    {
        // Update the flag based on the sign and move to the next character
        flag = (str[i++] == '-') ? -1 : 1;
    }

    // Iterate through the string and convert digits to integer
    while (str[i] >= '0' && str[i] <= '9')
    {
        // Update the result by multiplying by 10 and adding the digit value
        res = res * 10 + (str[i] - '0');
        // Move to the next character
        i++;
    }

    // Return the final result with appropriate sign
    return flag * res;
}
