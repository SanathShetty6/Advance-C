/*
NAME: SANATH SHETTY P
DATE: 03/04/2024
DESCRIPTION: Squeeze the character in s1 that matches any character in the string s2
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./squeeze
Enter s1 : Dennis Ritchie
Enter s2 : Linux

Test Case 2:
user@emertxe] ./squeeze
Enter s1 : Welcome
Enter s2 : Emertxe

SAMPLE OUTPUT:
Test Case 1: After squeeze s1 : Des Rtche
Test Case 2: After squeeze s1 : Wlco

*/

#include <stdio.h>

// Function prototype
void squeeze(char str1[], char str2[]);

int main()
{
    // Variable declaration
    char str1[30], str2[30];

    // Prompt user to enter string1
    printf("Enter string1: ");
    fgets(str1, 30, stdin); // Read string1 from user

    // Prompt user to enter string2
    printf("Enter string2: ");
    fgets(str2, 30, stdin); // Read string2 from user

    // Call squeeze function to remove characters from string1 that are present in string2
    squeeze(str1, str2);

    // Display the modified string1
    printf("After squeeze s1 : %s\n", str1);

    return 0;
}

// Function to remove characters from str1 that are present in str2
void squeeze(char str1[], char str2[])
{
    // Variable declaration
    int i, j, k;

    // Iterate through each character in str2
    for (j = 0; str2[j] != '\0'; j++)
    {
        // Iterate through each character in str1
        for (i = k = 0; str1[i] != '\0'; i++)
        {
            // If the character in str1 is not equal to the character in str2, keep it in str1
            if (str1[i] != str2[j])
            {
                str1[k++] = str1[i]; // Store the character in str1 at index k and increment k
            }
        }
        str1[k] = '\0'; // Add null terminator at the end of str1
    }
}
