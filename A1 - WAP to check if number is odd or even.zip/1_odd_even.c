/*
NAME: SANATH SHETTY P
DATE: 21/02/2024
DESCRIPTION: WAP to check if number is odd or even
SAMPLE INPUT:
Test Case 1:
Enter the value of 'n' : -2
Test Case 2:
Enter the value of 'n' : 2
Test Case 3:
Enter the value of 'n' : 0

SAMPLE OUTPUT:
Test Case 1:
-2 is negative even number
Test Case 2:
2 is positive even number
Test Case 3:
0 is neither odd nor even
*/
#include <stdio.h>
int main() {
    int n,out;                            //Declare the integer
    printf("Enter the number : ");          //Enter the input
    scanf("%d",&n);
    
    
    // Checking if n is even or odd
    if (n == 0) {
        printf("0 is neither odd nor even\n");
    } else if (n % 2 == 0) {
        // n is even
        if (n > 0) {
            // n is positive
            printf("%d is positive even number\n", n);
        } else {
            // n is negative
            printf("%d is negative even number\n", n);
        }
    } else {
        // n is odd
        if (n > 0) {
            // n is positive
            printf("%d is positive odd number\n", n);
        } else {
            // n is negative
            printf("%d is negative odd number\n", n);
        }
    }

    return 0;
}

