/*
NAME: SANATH SHETTY P
DATE: 27/02/2024
DESCRIPTION: WAP to find which day of the year
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./day_of_the_year
Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 2

Test Case 2:
Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 2

Test Case 3: 
Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 8

Test Case 4:
Enter the value of 'n' : 0

Test Case 5:
Enter the value of 'n' : 366

SAMPLE OUTPUT:
Test Case 1:
The day is Tuesday

Test Case 2:
The day is Wednesday

Test Case 3:

Error: Invalid input, first day should be > 0 and <= 7

Test Case 4:
Error: Invalid Input, n value should be > 0 and <= 365

Test Case 5:
Error: Invalid Input, n value should be > 0 and <= 365

*/

#include <stdio.h>

int main()
{
    int n,s,day;

    //Enter the input

    printf("Enter the value of 'n' : ");
    scanf("%d", &n);

    if( n >= 1 && n <= 365)
    {
        printf("Choose First Day :\n 1.Sunday\n 2.Monday\n 3.Tuesday\n 4.Wednesday\n 5.Thursday\n 6.Friday\n 7.Saturday\n"); 
        printf("Enter the option to set the first day : "); 
        scanf("%d", &s);

        if(s >= 1 && s <=7 )
        {
            day=((n+s-1)%7);

            switch (day)   //((n+s-1)%7)
            {
                case 0 :
                printf("The day is Saturday");
                break;
                case 1 :
                printf("The day is Sunday");
                break;
                case 2 :
                printf("The day is Monday");
                break;
                case 3 :
                printf("The day is Tuesday");
                break;
                case 4 :
                printf("The day is Wednesday");
                break;
                case 5 :
                printf("The day is Thursday");
                break;
                case 6 :
                printf("The day is Friday");
                break;
                            }
        }
        else
        {
            printf("Error: Invalid input, first day should be > 0 and <= 7");
        }
    }
    else
    {
        printf("Error: Invalid Input, n value should be > 0 and <= 365");
    }
    return 0;
}

