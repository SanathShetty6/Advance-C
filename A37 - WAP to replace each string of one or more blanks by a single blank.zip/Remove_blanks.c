/*
NAME: SANATH SHETTY P
DATE: 26/03/2024
DESCRIPTION: WAP to replace each string of one or more blanks by a single blank
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./remove_multi_space
Enter the string with more spaces in between two words
Pointers     are               sharp     knives.

Test Case 2:
user@emertxe] ./remove_multi_space
Enter the string with more spaces in between two words
Welcome                to Emertxe

Test Case 3:
user@emertxe] ./remove_multi_space
Enter the string with more spaces in between two words
Welcome to Emertxe

SAMPLE OUTPUT:
Test Case 1: Pointers are sharp knives.
Test Case 2: Welcome to Emertxe
Test Case 3: Welcome to Emertxe
*/

#include <stdio.h>

// Function prototype
void replace_blank(char []);

// Main function
int main()
{
    // Declare an array to store the input string
    char str[100];
    
    // Prompt the user to enter a string with spaces
    //printf("Enter the string with more spaces in between two words\n");
    // Read the string entered by the user
    scanf("%[^\n]", str);
    
    // Call the function to replace extra spaces with a single space
    replace_blank(str);
    
    // Print the modified string
    printf("%s\n", str);
}

// Function to replace extra spaces with a single space
void replace_blank(char *str)
{
    // Declare variables
    int i = 0, j;
    
    // Loop until the end of the string
    while (str[i + 1] != '\0')
    {
        // Replace tabs with spaces
        if (str[i] == '\t')
        {
            str[i] = ' ';
        }
        // Check for consecutive spaces or space followed by a tab
        if ((str[i] == ' ') && ((str[i + 1] == ' ') || (str[i + 1] == '\t')))
        {
            // Save the current index
            j = i;
            // Shift characters to the left to remove the extra space
            while (str[j] != '\0')
            {
                str[j] = str[j + 1];
                j++;
            }
            // Decrement the index to recheck the current position
            i--;
        }
        // Move to the next character in the string
        i++;
    }
}
