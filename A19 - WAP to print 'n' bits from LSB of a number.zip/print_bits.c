/*
NAME: SANATH SHETTY P
DATE: 08/03/2024
DESCRIPTION: WAP to print 'n' bits from LSB of a number
SAMPLE INPUT:
Test Case 1:
Enter the number: 10
Enter number of bits: 12

Test Case 2:
Enter the number: 15
Enter number of bits: 4

SAMPLE OUTPUT:
Test Case 1:Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0 
Test Case 2:Binary form of 15: 1 1 1 1
*/

#include <stdio.h>
//Funtion Declaration
int print_bits(int, int);

int main()
{
    //Integer declaration
    int num, n;
    
    //Enter the input
    //printf("Enter num, n :\n");
    //Read the input
    scanf("%d%d", &num, &n);
    //Print the ootput
    printf("Binary form of %d: ", num);
    //Call the function
    print_bits(num, n);
    return 0;
 }

//Function defination
int print_bits(int num, int n)
{
    //Declare integers required
    int i,bin;
    //Read the bits required to print
     for(i=n-1;i>=0;i--)
     {
        //Right shift num with i times and mask with 1
         bin=((num >> i) & 1);
         //Print the output
         printf("%d ", bin);
     }
}