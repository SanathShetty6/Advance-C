/*
NAME: SANATH SHETTY P
DATE: 27/02/2024
DESCRIPTION:
SAMPLE INPUT:
Test Case 1:
Enter the number: 4

Test Case 2:
Enter the number: 5

SAMPLE OUTPUT:
Test Case 1:
4
3 4
2 3 4
1 2 3 4
2 3 4
3 4
4

Test Case 2:
5
4 5
3 4 5
2 3 4 5
1 2 3 4 5
2 3 4 5
3 4 5
4 5
5
*/

#include <stdio.h>

int main()
{
    //Declare the integers
    int i,j,n;
    //Enter the inputs 
    printf("Enter the number: ");
    scanf("%d", &n);
    //Loop for upper half of pyramid
    for(i=n;i>=2;i--)               //loop for row  
    {
        for(j=i;j<=n;j++)           //loop for column
        {
            printf("%d ", j);        //Print the column output
        }
        printf("\n");
    }

    //Loop for lower half of pyramid
    for(i=1;i<=n;i++)               //loop for row
    {
        for(j=i;j<=n;j++)           //loop for column
        {
            printf("%d ", j);        //Print the column output
        }
        printf("\n");
    }
    return 0;
}

