/*
NAME: SANATH SHETTY P
DATE: 04/04/2024
DESCRIPTION: WAP to reverse the given string using recursive method
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./str_rev
Enter a string : Hello World

Test Case 2:
user@emertxe] ./str_rev
Enter a string : EMERTXE

SAMPLE OUTPUT:
Test Case 1: Reverse string is : dlroW olleH
Test Case 2: Reverse string is : EXTREME
*/
#include <stdio.h>

// Function prototypes
void reverse_recursive(char str[], int ind, int len);
int my_strlen(char str[]);

int main()
{
    // String declaration
    char str[30];

    // Prompt user to enter a string
    printf("Enter any string : ");
    // Read the string until newline character
    scanf("%30[^\n]", str);
    
    // Reverse the input string recursively
    reverse_recursive(str, 0, (my_strlen(str) - 1));
    
    // Display the reversed string
    printf("Reversed string is: %s\n", str);
}

// Function to calculate the length of a string
int my_strlen(char str[])
{
    int length = 0;
    while (str[length] != '\0')
    {
        length++;
    }
    return length;
}

// Function to reverse a string recursively
void reverse_recursive(char str[], int ind, int len)
{
    // Base case: if index surpasses length, return
    if (ind >= len)
    {
        return;
    }
    
    // Swap characters at indices ind and len
    char ch = str[ind];
    str[ind] = str[len];
    str[len] = ch;

    // Recursively call the function with updated indices
    reverse_recursive(str, ++ind, --len);
}
