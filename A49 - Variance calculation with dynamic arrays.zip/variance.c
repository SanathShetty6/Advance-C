/*
NAME: SANATH SHETTY P
DATE: 11/04/2024
DESCRIPTION: Variance calculation with dynamic arrays
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./variance
Enter the no.of elements : 10

Enter the 10 elements:
[0] -> 9
[1] -> 12
[2] -> 15
[3] -> 18
[4] -> 20
[5] -> 22
[6] -> 23
[7] -> 24
[8] -> 26
[9] -> 31

SAMPLE OUTPUT:
Test Case 1: Variance is 40.000000
*/

#include <stdio.h>
#include <stdlib.h>

// Function to calculate the variance of an array
float variance(int *arr, int size) {
    float mean = 0.0, sum = 0.0, deviation;

    // Calculate the mean
    for (int i = 0; i < size; i++) {
        mean += arr[i];
    }
    mean /= size;

    // Calculate the sum of squared deviations
    for (int i = 0; i < size; i++) {
        deviation = arr[i] - mean;
        sum += deviation * deviation;
    }

    // Calculate and return the variance
    return sum / size;
}

int main() {
    int *arr, size;

    // Read the number of elements from the user
    printf("Enter the number of elements: ");
    scanf("%d", &size);

    // Allocate memory dynamically for the array
    arr = (int *)malloc(size * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Read elements from the user
    printf("Enter the %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        printf("[%d] -> ", i);
        scanf("%d", &arr[i]);
    }

    // Calculate the variance and print it
    printf("Variance is %.6f\n", variance(arr, size));

    // Free allocated memory
    free(arr);

    return 0;
}
