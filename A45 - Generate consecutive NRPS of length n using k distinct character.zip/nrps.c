/*
NAME: SANATH SHETTY P
DATE: 05/04/2024
DESCRIPTION: Generate consecutive NRPS of length n using k distinct character
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./nrps
Enter the number characters C : 3
Enter the Length of the string N : 6
Enter 3 distinct characters : a b c


Test Case 2:
Enter the number characters C : 3
Enter the Length of the string N : 7
Enter 3 distinct characters : a b a


SAMPLE OUTPUT:
Test Case 1: Possible NRPS is abcbca
Test Case 2: Error : Enter distinct characters

*/

#include <stdio.h>

// Function prototype
void nrps(char str[], int len, int c);

int main()
{
    // Variable declaration
    int n, c, i, j;
    char distinct[100];
    
    // Read the number of distinct characters from the user
    printf("Enter the number of distinct characters C: ");
    scanf("%d", &c);

    // Read the length of the string (N) from the user
    printf("Enter the length of the string N: ");
    scanf("%d", &n);
    
    // Read distinct characters from the user
    printf("Enter %d distinct characters: ", c);
    for (i = 0; i < c; i++)
    {
        scanf("\n%c", &distinct[i]);
    }  
    
    // Check for distinct characters
    for (i = 0; i < c; i++)
    {
        for (j = i + 1; j < c; j++)
        {
            if (distinct[j] == distinct[i])
            {
                printf("Error: Enter distinct characters\n");
                return 1;
            }
        }
    }
    
    // Call the nrps function to generate the possible nrps
    printf("Possible NRPS is: ");
    nrps(distinct, n, c);
          
    return 0;
}

// Function to generate possible nrps
void nrps(char str[], int len, int c)
{
    // Variable declaration
    int i, val = 0;

    // Printing n characters
    for (i = 0; i < len; i++)
    {
        // Adjust val to handle cyclic behavior
        if (i % c == 0 && i != 0)
        {
            val++;
        }
        
        // Printing characters in reverse order
        printf("%c", str[(i + val) % c]);
    }
    printf("\n"); // Print a newline character after printing the nrps
}
