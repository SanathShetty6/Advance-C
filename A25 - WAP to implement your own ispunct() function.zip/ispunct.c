/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement your own ispunct() function
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./c_type_lib
Enter the character: $

Test Case 2:
Enter the character:a

SAMPLE OUTPUT:
Test Case 1: Entered character is punctuation character
Test Case 2: Entered character is not punctuation character
*/

#include <stdio.h>
//Function Declaration
int my_ispunct(char);

int main()
{
    char ch;            //Declare the character
    int ret;            //Declare the integer
    printf("Enter the character:");     //Enter the character
    scanf("%c", &ch);                   //Read the input
    
    ret = my_ispunct(ch);           //Call function
    if (ret == 1)                   // print whether character is punctuation or not
    {
        printf("Entered character is punctuation character");    //If ret equal to 1 print it is punctuation character
    }
    else
    {
        printf("Entered character is not punctuation character");    //Else print not punctuation character  
    }
}
//Function defination
int my_ispunct(char ch)
{
    if((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || (ch >= 91 && ch <= 95))    //Check the char ch is punctuation or not
    {
        return 1;       //If true return 1;
    }
    else{
        return 0;       //Else return 0;
    }
}





