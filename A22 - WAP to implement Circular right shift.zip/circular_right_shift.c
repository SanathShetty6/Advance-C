/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement Circular right shift
SAMPLE INPUT: 
Test Case 1:
user@emertxe] ./bit_ops
Enter num: 12
Enter n : 3

Test Case 2: 
Enter num: -12
Enter n : 3

SAMPLE OUTPUT:
Test Case 1: Result : 10000000 00000000 00000000 00000001
Test Case 2: Result : 10011111 11111111 11111111 11111110
*/
#include <stdio.h>
//Function declaration
int circular_right(int, int);
int print_bits(int);

int main()
{
    int num, n, ret;                //Integer declaration
    
    //printf("Enter the num:");       //Enter the value
    scanf("%d", &num);              //Read the integer input
    
    //printf("Enter n:");             //Enter the no of times to be shifted
    scanf("%d", &n);                //Read the input
    
    ret = circular_right(num, n);   //Call circular right shift function
    printf("Result in Binary: ");
    print_bits(ret);                //Call Print function
}
//Function defination for Circular right shift
int circular_right(int num, int n)
{
    int ret=(num >> n) & (~(((1 << n)-1) << (31 - n + 1))) | (num & ((1 << n)-1)) << (31 - n + 1); //Perform circular right shift
    return ret;
}
//Function defination for printing bits
int print_bits(int ret)
{
    for( int i = 0  ; i < 32; i++)                     // loop printing each binary value msb to lsb
    { 
        if( (ret >> 31 -i) & 1)                      // mulitiple ret value >> 31 -i times and mask with 1    
            
            printf("1 ");                           //If condition is true print 1
         
        else

            printf("0 ");                           //Else print false
           
    }

}
