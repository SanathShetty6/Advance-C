/*
NAME: SANATH SHETTY P
DATE: 12/03/2024
DESCRIPTION: WAP to implement your own isalnum() function
SAMPLE INPUT:
Test Case 1:
user@emertxe] ./c_type_lib
Enter the character: a

Test Case 2:
Enter the character: ?

SAMPLE OUTPUT:
Test Case 1:The character 'a' is an alnum character.
Test Case 2:The character '?' is not an alnum character.
*/

#include <stdio.h>
//Declare the function
int my_isalnum(char);

int main()
{
    char ch;                    //Declare the character ch
    int ret;                    //Declare the integer

    //printf("Enter the character:"); //Enter the input to ch
    scanf("%c", &ch);               //Read the input

    ret = my_isalnum(ch);           //Call the function

    if (ret == 1)                   // print whether ch is alphanumeric or not
    {
        printf("Entered character is alphanumeric character");    //If ret equal to 1 print it is alnum
    }
    else
    {
        printf("Entered character is not alphanumeric character");    //Else print not an alnum   
    }
}

//Function defination
int my_isalnum(char ch ){
    if( (ch >= '0' && ch <='9' ) || (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))     //Check the char ch is between these  numbers
    {
        return 1;       //If true return 1;
    }
    else{
        return 0;       //Else return 0;
    }
}
